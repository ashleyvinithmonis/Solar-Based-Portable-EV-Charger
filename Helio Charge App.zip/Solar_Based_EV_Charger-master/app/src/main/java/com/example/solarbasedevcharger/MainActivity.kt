package com.example.solarbasedevcharger

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

private const val TAG = "SolarBLE"
private const val FILE_NAME = "session_history.txt"

private val SERVICE_UUID = UUID.fromString("4fa4c201-1fb2-45fe-a22c-a54179531c9b")
private val CHARACTERISTIC_UUID = UUID.fromString("beb5483e-36e1-4688-b7f5-ea07361b26a8")
private val CLIENT_CHARACTERISTIC_CONFIG_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

// Brand Palette (Solar Amber Gold & Energy Green)
private val SolarGold = Color(0xFFFFB800)
private val SolarGoldDark = Color(0xFFF59E0B)
private val EnergyGreen = Color(0xFF10B981)
private val SlateNavy = Color(0xFF0F172A)
private val SlateGray = Color(0xFF64748B)
private val CardBg = Color(0xFFFFFFFF)
private val ScreenBg = Color(0xFFF8FAFC)
private val BorderColor = Color(0xFFE2E8F0)

class MainActivity : ComponentActivity() {

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothGatt: BluetoothGatt? = null

    // Telemetry UI States
    private var connectionStatus by mutableStateOf("Disconnected")
    private var sourceVoltage by mutableStateOf("0.00 V")
    private var loadVoltage by mutableStateOf("0.00 V")
    private var currentDraw by mutableStateOf("0.00 A")
    private var elapsedSeconds by mutableStateOf(0L)

    // Peak Telemetry States
    private var peakSourceVolt by mutableStateOf("0.0 V")
    private var peakLoadVolt by mutableStateOf("0.0 V")
    private var peakCurrent by mutableStateOf("0.0 A")

    // Session History Tracking States
    private val uiSessionHistoryLogs = mutableStateListOf<String>()
    private var isSessionActive = false
    private var sessionStartTimeStr = ""
    private var lastValidDuration = "00:00:00"
    private var peakInfoStr = ""

    // Dynamic Graph History Cache Arrays
    private val sourceHistory = mutableStateListOf<Float>()
    private val loadHistory = mutableStateListOf<Float>()
    private val currentHistory = mutableStateListOf<Float>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        loadSavedHistoryAsync()

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        setContent {
            SolarChargerTheme {
                AppScreen()
            }
        }

        checkAndRequestPermissions()
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun AppScreen() {
        var selectedTab by remember { mutableStateOf(0) }

        Scaffold(
            topBar = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(SlateNavy, Color(0xFF1E293B))
                            )
                        )
                ) {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(SolarGold)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    "Helio Charge Monitor",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 19.sp,
                                    color = Color.White
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Transparent
                        )
                    )
                }
            },
            containerColor = ScreenBg
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Connection Header Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(
                                        color = if (connectionStatus == "Connected") EnergyGreen else Color(0xFFEF4444)
                                    )
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "CHARGER STATUS",
                                    fontSize = 10.sp,
                                    color = SlateGray,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = connectionStatus,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = if (connectionStatus == "Connected") EnergyGreen else Color(0xFFDC2626)
                                )
                            }
                        }
                        Button(
                            onClick = {
                                if (connectionStatus == "Disconnected") startBleScan() else disconnectBle()
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (connectionStatus == "Disconnected") SolarGold else SlateGray
                            )
                        ) {
                            Text(
                                if (connectionStatus == "Disconnected") "Connect" else "Disconnect",
                                fontWeight = FontWeight.Bold,
                                color = if (connectionStatus == "Disconnected") SlateNavy else Color.White
                            )
                        }
                    }
                }

                // Tab Navigation bar
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = CardBg,
                    contentColor = SolarGoldDark,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = SolarGold,
                            height = 3.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        selectedContentColor = SolarGoldDark,
                        unselectedContentColor = SlateGray
                    ) {
                        Text("Telemetry", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold)
                    }
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        selectedContentColor = SolarGoldDark,
                        unselectedContentColor = SlateGray
                    ) {
                        Text("History Log", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold)
                    }
                }

                Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    if (selectedTab == 0) {
                        TelemetryTab()
                    } else {
                        HistoryTab()
                    }
                }
            }
        }
    }

    @Composable
    fun TelemetryTab() {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Live Metrics", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SlateNavy)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Solar Array", sourceVoltage, Modifier.weight(1f), SolarGold)
                MetricCard("Output Load", loadVoltage, Modifier.weight(1f), EnergyGreen)
                MetricCard("Current Flow", currentDraw, Modifier.weight(1f), SlateNavy)
            }

            // High Tech Chart
            MultiLineTelemetryGraphCard(sourceHistory, loadHistory, currentHistory)

            // Active Duration Indicator
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ACTIVE DURATION", fontSize = 10.sp, color = SlateGray, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = formatSeconds(elapsedSeconds),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = EnergyGreen,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(EnergyGreen.copy(alpha = 0.12f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("STREAMING", color = EnergyGreen, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
                    }
                }
            }

            // Web App Link
            Button(
                onClick = {
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://helio-charge-li0m.arcada.app/"))
                    startActivity(browserIntent)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SlateNavy),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(text = "View Web Dashboard", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
            }

            Text("Session Peak Records", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SlateNavy)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Peak Solar", peakSourceVolt, Modifier.weight(1f), SolarGold, isOutline = true)
                MetricCard("Peak Load", peakLoadVolt, Modifier.weight(1f), EnergyGreen, isOutline = true)
                MetricCard("Peak Current", peakCurrent, Modifier.weight(1f), SlateNavy, isOutline = true)
            }
        }
    }

    @Composable
    fun MultiLineTelemetryGraphCard(srcList: List<Float>, ldList: List<Float>, curList: List<Float>) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Telemetry Stream", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SlateNavy)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LegendItem("Solar", SolarGold)
                        LegendItem("Load", SlateNavy)
                        LegendItem("Current", EnergyGreen)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                if (srcList.isEmpty() && ldList.isEmpty() && curList.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Waiting for Bluetooth stream...", color = SlateGray, fontSize = 12.sp)
                    }
                } else {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height
                        val maxPoints = 30
                        val gridLines = 4

                        for (i in 0..gridLines) {
                            val y = (height / gridLines) * i
                            drawLine(
                                color = Color(0xFFF1F5F9),
                                start = Offset(0f, y),
                                end = Offset(width, y),
                                strokeWidth = 1.5f
                            )
                        }

                        val highestValue = maxOf(
                            srcList.maxOrNull() ?: 1f,
                            ldList.maxOrNull() ?: 1f,
                            curList.maxOrNull() ?: 1f
                        )
                        val yMax = if (highestValue < 1f) 5f else highestValue * 1.15f
                        val stepX = width / (maxPoints - 1)

                        fun calculatePoints(list: List<Float>): List<Offset> {
                            return list.mapIndexed { idx, value ->
                                val x = idx * stepX
                                val fraction = value / yMax
                                val y = height - (fraction * height)
                                Offset(x, y)
                            }
                        }

                        val srcPoints = calculatePoints(srcList)
                        val ldPoints = calculatePoints(ldList)
                        val curPoints = calculatePoints(curList)

                        if (srcPoints.isNotEmpty()) {
                            val srcPath = Path().apply {
                                moveTo(srcPoints.first().x, srcPoints.first().y)
                                for (i in 1 until srcPoints.size) { lineTo(srcPoints[i].x, srcPoints[i].y) }
                            }
                            drawPath(path = srcPath, color = SolarGold, style = Stroke(width = 3.5f))
                        }

                        if (ldPoints.isNotEmpty()) {
                            val ldPath = Path().apply {
                                moveTo(ldPoints.first().x, ldPoints.first().y)
                                for (i in 1 until ldPoints.size) { lineTo(ldPoints[i].x, ldPoints[i].y) }
                            }
                            drawPath(path = ldPath, color = SlateNavy, style = Stroke(width = 3.5f))
                        }

                        if (curPoints.isNotEmpty()) {
                            val curPath = Path().apply {
                                moveTo(curPoints.first().x, curPoints.first().y)
                                for (i in 1 until curPoints.size) { lineTo(curPoints[i].x, curPoints[i].y) }
                            }

                            val fillPath = Path().apply {
                                moveTo(0f, height)
                                curPoints.forEach { lineTo(it.x, it.y) }
                                lineTo((curPoints.size - 1) * stepX, height)
                                close()
                            }
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(EnergyGreen.copy(alpha = 0.25f), Color.Transparent),
                                    startY = 0f,
                                    endY = height
                                )
                            )
                            drawPath(path = curPath, color = EnergyGreen, style = Stroke(width = 3.5f))
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun LegendItem(label: String, color: Color) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).background(color, shape = CircleShape))
            Spacer(modifier = Modifier.width(4.dp))
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SlateGray)
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun HistoryTab() {
        var showConfirmationDialog by remember { mutableStateOf(false) }
        var selectedDateFilter by remember { mutableStateOf("") } // Date string "YYYY-MM-DD"
        var showDatePicker by remember { mutableStateOf(false) }

        val filteredLogs = remember(selectedDateFilter, uiSessionHistoryLogs.toList()) {
            if (selectedDateFilter.isBlank()) {
                uiSessionHistoryLogs
            } else {
                uiSessionHistoryLogs.filter { log ->
                    log.contains(selectedDateFilter)
                }
            }
        }

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Charging History", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = SlateNavy)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Filter Date Button
                    OutlinedButton(
                        onClick = { showDatePicker = true },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (selectedDateFilter.isNotEmpty()) EnergyGreen else SlateNavy
                        )
                    ) {
                        Text(
                            text = if (selectedDateFilter.isNotEmpty()) selectedDateFilter else "Filter Date",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Clear Logs Button
                    Button(
                        onClick = { showConfirmationDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFEE2E2),
                            contentColor = Color(0xFFDC2626)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Clear Logs", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Active Filter Chip Indicator
            if (selectedDateFilter.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(EnergyGreen.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Filtered by: $selectedDateFilter (${filteredLogs.size} records)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = EnergyGreen
                    )
                    TextButton(
                        onClick = { selectedDateFilter = "" },
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Text("Reset", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredLogs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (selectedDateFilter.isNotEmpty()) "No records found for $selectedDateFilter" else "No charging records found.",
                        color = SlateGray,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredLogs) { log ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardBg),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Text(
                                text = log,
                                modifier = Modifier.padding(14.dp),
                                fontSize = 12.sp,
                                color = SlateNavy,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Material 3 Date Picker Dialog
        if (showDatePicker) {
            val datePickerState = rememberDatePickerState()

            DatePickerDialog(
                onDismissRequest = { showDatePicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            datePickerState.selectedDateMillis?.let { millis ->
                                val calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                                    timeInMillis = millis
                                }
                                val formattedDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)
                                selectedDateFilter = formattedDate
                            }
                            showDatePicker = false
                        }
                    ) {
                        Text("Apply", fontWeight = FontWeight.Bold, color = EnergyGreen)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDatePicker = false }) {
                        Text("Cancel", color = SlateGray)
                    }
                }
            ) {
                DatePicker(state = datePickerState)
            }
        }

        // Delete Confirmation Dialog
        if (showConfirmationDialog) {
            AlertDialog(
                onDismissRequest = { showConfirmationDialog = false },
                title = { Text("Clear Charging History?", color = SlateNavy, fontWeight = FontWeight.Bold) },
                text = { Text("Are you sure you want to permanently delete all saved session logs?") },
                confirmButton = {
                    Button(
                        onClick = {
                            clearSavedHistoryAsync()
                            showConfirmationDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                    ) {
                        Text("Delete", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showConfirmationDialog = false }) {
                        Text("Cancel", color = SlateGray)
                    }
                }
            )
        }
    }

    @Composable
    fun MetricCard(
        title: String,
        value: String,
        modifier: Modifier = Modifier,
        accentColor: Color,
        isOutline: Boolean = false
    ) {
        Card(
            modifier = modifier,
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isOutline) CardBg else accentColor.copy(alpha = 0.08f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isOutline) 1.dp else 0.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isOutline) BorderColor else accentColor.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(title, fontSize = 10.sp, color = SlateGray, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(value, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = SlateNavy)
            }
        }
    }

    private fun saveSessionToStorageAsync(sessionRecord: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val file = File(filesDir, FILE_NAME)
                file.appendText(sessionRecord + "\n\n")
            } catch (e: Exception) {
                Log.e(TAG, "Error writing history file: ", e)
            }
        }
    }

    private fun loadSavedHistoryAsync() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val file = File(filesDir, FILE_NAME)
                if (file.exists()) {
                    val contents = file.readText()
                    val sessions = contents.split("\n\n")
                        .filter { it.isNotBlank() }
                        .reversed()

                    withContext(Dispatchers.Main) {
                        uiSessionHistoryLogs.clear()
                        uiSessionHistoryLogs.addAll(sessions)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed loading records asynchronously: ", e)
            }
        }
    }

    private fun clearSavedHistoryAsync() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val file = File(filesDir, FILE_NAME)
                if (file.exists()) file.delete()

                withContext(Dispatchers.Main) {
                    uiSessionHistoryLogs.clear()
                    Toast.makeText(this@MainActivity, "Logs Cleared Successfully", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error cleaning logs: ", e)
            }
        }
    }

    private fun finalizeCurrentChargingSession() {
        if (!isSessionActive) return
        isSessionActive = false

        val endTimeStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        val sessionSummary = "SESSION RECORD\n" +
                "Started : $sessionStartTimeStr\n" +
                "Ended   : $endTimeStr\n" +
                "Duration: $lastValidDuration\n" +
                "${peakInfoStr.trim()}\n" +
                "-----------------------------------"

        saveSessionToStorageAsync(sessionSummary)

        runOnUiThread {
            uiSessionHistoryLogs.add(0, sessionSummary)
        }
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val deviceName = try { device.name } catch (e: SecurityException) { null }

            if (deviceName == "Your Car Solar Charger") {
                runOnUiThread { connectionStatus = "Connecting..." }
                try {
                    bluetoothAdapter?.bluetoothLeScanner?.stopScan(this)
                } catch (e: SecurityException) {
                    Log.e(TAG, "Scan stop permission error", e)
                }
                bluetoothGatt = device.connectGatt(this@MainActivity, false, gattCallback)
            }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                runOnUiThread { connectionStatus = "Connection Failed" }
                try { gatt.close() } catch (e: SecurityException) {}
                bluetoothGatt = null
                return
            }

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { connectionStatus = "Connected" }
                try { gatt.discoverServices() } catch (e: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread {
                    connectionStatus = "Disconnected"
                    finalizeCurrentChargingSession()
                }
                try { gatt.close() } catch (e: SecurityException) {}
                bluetoothGatt = null
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val service = gatt.getService(SERVICE_UUID)
                val characteristic = service?.getCharacteristic(CHARACTERISTIC_UUID)
                if (characteristic != null) {
                    try {
                        gatt.setCharacteristicNotification(characteristic, true)

                        val descriptor = characteristic.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG_UUID)
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        gatt.writeDescriptor(descriptor)
                    } catch (e: SecurityException) {
                        Log.e(TAG, "Descriptor write permission error", e)
                    }
                }
            }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val data = characteristic.value?.let { String(it) } ?: return

            runOnUiThread {
                if (data.startsWith("PEAKS:")) {
                    try {
                        val trimmed = data.substring(6)
                        val parts = trimmed.split(",")
                        peakSourceVolt = parts[0].substringAfter("SrcMax=")
                        peakLoadVolt = parts[1].substringAfter("LdMax=")
                        peakCurrent = parts[2].substringAfter("CurMax=")

                        peakInfoStr = "Peaks   : Solar=$peakSourceVolt | Load=$peakLoadVolt | Current=$peakCurrent"
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing peaks payload: $data", e)
                    }
                } else {
                    try {
                        val tokens = data.split(",")
                        if (tokens.size >= 4) {
                            val srcVal = tokens[0].toFloatOrNull() ?: 0.0f
                            val ldVal = tokens[1].toFloatOrNull() ?: 0.0f
                            val currentVal = tokens[2].toFloatOrNull() ?: 0.0f

                            sourceVoltage = "$srcVal V"
                            loadVoltage = "$ldVal V"
                            currentDraw = "$currentVal A"
                            elapsedSeconds = tokens[3].toLongOrNull() ?: 0L

                            if (sourceHistory.size >= 30) sourceHistory.removeAt(0)
                            if (loadHistory.size >= 30) loadHistory.removeAt(0)
                            if (currentHistory.size >= 30) currentHistory.removeAt(0)

                            sourceHistory.add(srcVal)
                            loadHistory.add(ldVal)
                            currentHistory.add(currentVal)

                            if (currentVal > 0.05f) {
                                if (!isSessionActive) {
                                    isSessionActive = true
                                    sessionStartTimeStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                                }
                                lastValidDuration = formatSeconds(elapsedSeconds)
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing telemetry CSV layout: $data", e)
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBleScan() {
        if (!hasRequiredPermissions()) {
            Toast.makeText(this, "Permissions required", Toast.LENGTH_SHORT).show()
            return
        }
        connectionStatus = "Scanning..."
        try {
            bluetoothAdapter?.bluetoothLeScanner?.startScan(scanCallback)
        } catch (e: SecurityException) {
            connectionStatus = "Scan Failed: Permission Denied"
        }
    }

    @SuppressLint("MissingPermission")
    private fun disconnectBle() {
        try {
            bluetoothGatt?.disconnect()
        } catch (e: SecurityException) {
            Log.e(TAG, "Disconnect permission error", e)
        }
    }

    private fun formatSeconds(totalSeconds: Long): String {
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
    }

    private fun hasRequiredPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissionLauncher.launch(missing.toTypedArray())
        }
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            Log.d(TAG, "All permissions successfully granted by user.")
        } else {
            Toast.makeText(this, "BLE permissions are required for this application", Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
fun SolarChargerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = SolarGold,
            primaryContainer = CardBg,
            onPrimaryContainer = SlateNavy,
            error = Color(0xFFDC2626),
            background = ScreenBg
        ),
        content = content
    )
}